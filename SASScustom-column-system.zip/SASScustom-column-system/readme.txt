�Hola! Gracias por clonarme/conseguirme, pertenezco al Github de:

https://github.com/helleworldGIT?tab=repositories

Concretamente en el repositorio:

https://github.com/helleworldGIT/SASS-Resources


*Para compilar los nuevos estilos no olvides entrar a la carpeta
CSS, abrir la consola y utilizar el siguiente comando:
sass main.scss:main.css --watch
para que cada vez que guardes el SASS se autocompile.

Si haces algo chuli, �qu� tal si lo compartes? :)

TWITTER: @helleworld_